SERVER_URL = "https://sitemanager.techguyry.com/swarmada"
